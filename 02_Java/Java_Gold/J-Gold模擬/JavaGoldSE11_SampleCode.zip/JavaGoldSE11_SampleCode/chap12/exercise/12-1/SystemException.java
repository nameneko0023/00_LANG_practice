public class SystemException extends RuntimeException {
  public SystemException(String msg) {
    super(msg);
  }
}
