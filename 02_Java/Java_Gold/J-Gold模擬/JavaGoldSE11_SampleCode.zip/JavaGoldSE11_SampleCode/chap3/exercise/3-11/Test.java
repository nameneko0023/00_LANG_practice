public class Test {
  public static void main(String[] args) {
    java.util.ArrayList<String> list = null;
    assert list != null;
  }
}
