public class Test {
  public static void main(String[] args) {
    if(args.length <= 2) assert false;
    System.out.println(args[0] + args[1]);
  }
}
