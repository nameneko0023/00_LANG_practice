@FunctionalInterface
interface FuncInter<T> {
  boolean equals(Object obj);
}