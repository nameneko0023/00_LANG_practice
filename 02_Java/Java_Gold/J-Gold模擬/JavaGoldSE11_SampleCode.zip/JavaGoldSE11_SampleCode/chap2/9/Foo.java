@MyAnnot
public class Foo {
  
  @MyAnnot
  public void method(int a) {
    
  }
}