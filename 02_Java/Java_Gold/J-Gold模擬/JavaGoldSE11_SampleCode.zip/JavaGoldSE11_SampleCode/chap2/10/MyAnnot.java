public @interface MyAnnot {
  String value();
}