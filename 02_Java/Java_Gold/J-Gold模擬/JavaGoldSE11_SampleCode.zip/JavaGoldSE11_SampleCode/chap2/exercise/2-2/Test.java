import java.util.*;

public class Test {
  public static void main(String[] args) {
    System.out.println(getData());
  }
  �y   �@   �z
  public static Set getData() {
    Set set = new HashSet();
    set.add(10); set.add(20); 
    return set;
  }
}
