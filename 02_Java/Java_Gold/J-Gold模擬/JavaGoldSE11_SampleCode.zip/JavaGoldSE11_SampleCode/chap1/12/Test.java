interface Test {
  int a;
  protected void methodA();
  final void methodB();
  static void methodC();
}
