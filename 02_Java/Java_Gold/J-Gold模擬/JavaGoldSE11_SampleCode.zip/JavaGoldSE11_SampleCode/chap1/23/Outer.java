class Outer {
  class A { }
  static class B { }
}
