class Outer {
  private String str;
  private class Inner {
    public boolean bar() { return true; }
  }
}