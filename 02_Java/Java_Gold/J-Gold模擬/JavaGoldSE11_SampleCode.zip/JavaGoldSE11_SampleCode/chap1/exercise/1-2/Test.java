public class Test {
  enum Vals { X, Y, Z }
  public static void main(String[] args) {
    System.out.println(Vals.X.ordinal());
  }
}
