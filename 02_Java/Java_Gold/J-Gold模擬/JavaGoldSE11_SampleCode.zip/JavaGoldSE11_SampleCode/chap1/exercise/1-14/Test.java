public class Test {
  class Foo { }
  public static void main(String[] args) {
     �y   �@   �z
  }
}
