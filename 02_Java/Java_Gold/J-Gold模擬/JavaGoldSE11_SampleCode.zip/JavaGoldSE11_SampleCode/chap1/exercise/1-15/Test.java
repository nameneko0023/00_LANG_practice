public class Test {
  void bar() { }
  class Foo extends Test { 
    �y   �@   �z
  }
}
