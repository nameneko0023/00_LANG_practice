public interface Test {
  int number = 100;
  public static String method();
  public int foo() { return 0; }
}