interface A { }
class B implements A {
  public static void main(String[] args) {
    �y   �@   �z obj = new D();
  }
}
class C extends B { }
class D extends B { }