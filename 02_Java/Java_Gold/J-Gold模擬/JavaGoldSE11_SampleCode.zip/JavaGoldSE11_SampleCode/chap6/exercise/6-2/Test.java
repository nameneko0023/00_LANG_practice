import java.util.*;
public class Test {
  public static void main(String[] args) {
    Set<String> set = new HashSet<>();
    set.add("c"); set.add("a"); set.add("b");
    set.forEach(�y   �@   �z);
  }
}
