import java.util.*;
import java.util.stream.*;

public class Main {
  public static void main(String[] args) {
    //List<String> list = Arrays.asList("a", "b", "c");
    //Stream<String> stream = list.stream(); 
    
    //String[] ary = {"a", "b", "c"};
    //Stream<String> stream = Arrays.stream(ary);
    
    //int[] ary = {1, 2, 3};
    //IntStream stream = Arrays.stream(ary); 
    
    //Stream<String> stream = Stream.of("abc");
    
    //Stream<Long> stream = Stream.of(1L, 2L, 3L);
    
    //Stream<String> stream = Stream.empty();
    
    //Stream<String> stream = Stream.generate(() -> "Java");
    
    //IntStream stream = IntStream.of(1, 2, 3);
    
    //IntStream stream = IntStream.iterate(1, n -> n + 1);
    
    //IntStream.iterate(1, n -> n <= 10, n -> n + 1);
    
    //IntStream stream = IntStream.range(1, 10);
    
    //IntStream stream = IntStream.rangeClosed(1, 10);
  }
}
