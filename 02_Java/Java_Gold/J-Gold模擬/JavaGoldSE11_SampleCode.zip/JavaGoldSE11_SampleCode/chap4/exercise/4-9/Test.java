import java.util.*;
public class Test {
  public static void main(String[] args) {
    Map map = new HashMap();
    map.put(23, "data1");
    map.put(2.4, "data2");
    System.out.println(map.contains(2));
  }
}
