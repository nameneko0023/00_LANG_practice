import java.util.*;
public class Test {
  public static void main(String[] args) {
    
    //Map<String, ? extends Number> cols1 = new HashMap<String, Integer>();
    
    //List<String> cols2 = new HashSet<String>();
    
    //List<Object> cols3 = new ArrayList<? extends Object>();
    
    //HashSet<Number> cols4 = new HashSet<Long>(); 

    //HashSet<? super IllegalStateException> cols5 = new HashSet<Exception>();
    
    //List<> cols6 = new ArrayList<String>(); 
    
  }
}
