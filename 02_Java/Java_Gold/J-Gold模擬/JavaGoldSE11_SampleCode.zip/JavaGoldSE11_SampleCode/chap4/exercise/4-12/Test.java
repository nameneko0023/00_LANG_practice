import java.util.*;
public class Test {
  public static void main(String[] args) {
    �y   �@   �z
    foo(obj);
  }
  public static void foo(List<?> list) {
    System.out.println(list.size());
  }
}
