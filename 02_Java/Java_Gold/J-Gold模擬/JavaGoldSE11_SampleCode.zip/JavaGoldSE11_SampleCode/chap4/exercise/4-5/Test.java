import java.util.*;
public class Test {
  public static void main(String[] args) {
    List<Double> list = Arrays.asList(1.0, 2.2, 3.5);
    Iterator iter = list.iterator();
    while(iter.�y   �@   �z()) System.out.print(iter.�y   �A   �z());
  }
}
