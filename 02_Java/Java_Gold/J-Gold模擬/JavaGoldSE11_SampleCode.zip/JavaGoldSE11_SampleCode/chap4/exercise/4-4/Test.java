import java.util.*;
public class Test {
  public static void main(String[] args) {
    �y   �@   �z<Integer> list = new LinkedList<>();
    list.add(100); list.add(200); 
    list.remove(1);
    System.out.println(list);
  }
}
