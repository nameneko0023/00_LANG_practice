import java.nio.file.*;

public class Test {
  public static void main(String[] args) {
    
    //Path path1 = FileSystems.getDefault().getPath("a.txt"); // A
    //Path path2 = new Fileystem().getPath("a.txt"); // B
    //Path path3 = Paths.get("foo", "a.txt");  // C
    //Path path4 = Paths.getPath("a.txt");     // D
    //Path path5 = new java.io.File("a.txt").toPath();  // E
    //Path path6 = new Path("a.txt");  // F
  }
}
