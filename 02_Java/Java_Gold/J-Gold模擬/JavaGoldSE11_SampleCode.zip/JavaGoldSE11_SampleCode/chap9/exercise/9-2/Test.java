import java.io.*;

public class Test {
  public static void main(String[] args) {
    Console console = System.console();
    �y   �@   �z
    �y   �A   �z
    str = console.readLine();  
     pw = console.readPassword();
  }
}