import java.io.*;

public class Test {
  public static void main(String[] args){
    //File file = new File("/home/yuko/mypic/cooking.png");
    //File file = new File("/home/yuko/mypic/" , new File("cooking.png"));
    //File file = new File("/home/yuko", "/mypic/cooking.png");
    //File file = new File("/home", "/yuko", "/mypic", "/cooking.png");
    //File file = new File(new File("/home"), "/yuko/mypic/cooking.png");
    System.out.println(file);
  }
}