import java.util.function.*;

public class Test {
  public static void main(String[] args) {
    UnaryOperator<Integer> o = a -> a * 15;
  }
}
