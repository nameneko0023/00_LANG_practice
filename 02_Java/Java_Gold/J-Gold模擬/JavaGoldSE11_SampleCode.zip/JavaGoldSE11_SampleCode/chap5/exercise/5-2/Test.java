import java.util.function.*;
public class Test {
  public static void main(String[] args) {
    �y   �@   �z obj1 = String::new;
    �y   �A   �z obj2 = (a, b) -> System.out.println(a+b);
    �y   �B   �z obj3 = a -> a.toUpperCase();
  }
}
