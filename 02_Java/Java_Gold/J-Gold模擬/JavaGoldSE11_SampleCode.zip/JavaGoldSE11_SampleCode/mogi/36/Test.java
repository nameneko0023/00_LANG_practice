import java.util.stream.*;
public class Test {
  public static void main(String[] args) {
    Stream<String> stream = Stream.of(" ");
    boolean x = stream.�y   �@   �z(String::isEmpty);
    System.out.println(x);
  }
}
