import java.util.function.*;
import java.util.*;

public class Test {
  public static void main(String[] args) {
    int val = 0;
    for(int i = 1; i <= 10; i++){
      val += i;
    }
    System.out.println(val);
  }
}
