import java.util.*;
public class Test {
  public static void main(String[] args) {
    //List<Integer> obj = new Vector<Integer>(); // A
    //List<Object> obj = new HashSet<Object>(); // B
    //List<Object> obj = new LinkedList<? extends Object>(); // C
    //HashSet<Number> obj = new HashSet<Double>(); // D
    //HashSet<? super ArithmeticException> obj = new HashSet<Exception>(); // E
    //Map<String, ? extends Number> obj = new HashMap<String, Double>(); // F
  }
}
