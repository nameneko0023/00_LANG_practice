import java.util.*;
import java.util.function.*;
import java.util.stream.*;
public class Test {
  public static void main(String[] args) {
    List<Integer> x = Arrays.asList(40, 20);
    List<Integer> y = Arrays.asList(10, 30);
    �y   �@   �z
  }
}
