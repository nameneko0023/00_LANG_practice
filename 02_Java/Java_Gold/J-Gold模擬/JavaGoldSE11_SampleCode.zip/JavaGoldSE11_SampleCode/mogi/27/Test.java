class Foo�y   �@   �z {  }
public class Test {
  public static void main(String[] args) {
    Foo<Integer> obj1 = new Foo�y   �A   �z();
    Foo<Object> obj2 = new Foo();
  }
}
