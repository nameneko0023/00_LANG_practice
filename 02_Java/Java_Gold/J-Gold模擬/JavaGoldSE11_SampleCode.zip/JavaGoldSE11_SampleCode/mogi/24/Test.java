import java.util.*;

public class Test {
  public static void main(String[] args) {
    
    /*
    Comparator comp = new Comparator<?>() {
      public int compare(Integer x, Integer y) {
        return x.compareTo(y);
      }
    };
    */
    
    /*
    Comparator<Integer> comp = new Comparator<>() {
      public int compare(Integer x, Integer y) {
        return x.compareTo(y);
      }
    };
    */
    
     /*
    Comparator<> comp = new Comparator<Integer>() {
      public int compare(Integer x, Integer y) {
        return x.compareTo(y);
      }
    };
    */
    
    
    //Comparator<Integer> comp = (x, y) -> Integer.compare(x, y);

    
    //var comp = (x, y) -> Integer.compare(x, y);
    
  }
}
