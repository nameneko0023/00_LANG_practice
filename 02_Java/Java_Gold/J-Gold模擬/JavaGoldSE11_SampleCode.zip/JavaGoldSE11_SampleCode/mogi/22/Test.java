import java.util.*;
public class Test {
  public static void main(String[] args) {
    Map<String, Double> map = new HashMap<>();
    //map.put(10.0);
    //map.add("val", 10L);
    //map.put(new Double(0.0));
    //map.add("val", 0.0);
    
  }
}
