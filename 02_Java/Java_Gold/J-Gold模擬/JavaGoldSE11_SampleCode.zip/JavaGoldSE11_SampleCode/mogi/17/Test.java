import java.io.*;
public class Test {
  public static void main(String[] args) {
    
  }
  private int method(int x, int y) {
    boolean assert = false;
    assert ++x > 0;
    assert y > 0;
    return x + y;
  }
}
