public class Test {
  public static void main(String[] args) {
    
  }
  public static T method(T t) { return t; }
}
