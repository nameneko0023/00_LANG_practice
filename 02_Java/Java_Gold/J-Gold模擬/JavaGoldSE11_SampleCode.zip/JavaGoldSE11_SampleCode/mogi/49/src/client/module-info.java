/*  // A
module seapp {
  requires util;
  requires format5;
  requires convert4;
}
*/

/*  // B
module seapp {
  requires util;
  requires com.se.format5;
  requires com.se.convert4;
}
*/

/*  // C
module seapp {
  requires util2;
  requires format5;
  requires convert4;
}
*/

/*  // D
module seapp {
  requires util-2.0.1;
  requires com.se.format5;
  requires com.se.convert4;
}
*/
