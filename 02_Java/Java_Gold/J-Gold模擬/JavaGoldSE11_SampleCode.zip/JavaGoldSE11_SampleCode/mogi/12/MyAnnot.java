import java.lang.annotation.*;
import static java.lang.annotation.ElementType.*;

@Target({TYPE, METHOD, PARAMETER})
public @interface MyAnnot {
}

