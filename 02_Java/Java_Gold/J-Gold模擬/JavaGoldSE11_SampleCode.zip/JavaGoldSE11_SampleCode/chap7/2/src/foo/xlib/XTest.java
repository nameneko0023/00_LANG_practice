package xlib;
import ylib.YTest;
public class XTest {
  public static void x() {
    System.out.println("XTest::x");
    YTest.y(); // YTest��y()�Ăяo��
  }
}
