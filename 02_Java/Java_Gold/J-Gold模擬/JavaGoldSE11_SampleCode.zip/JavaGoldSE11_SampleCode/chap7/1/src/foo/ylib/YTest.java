package ylib;

public class YTest {
  public static void y() {
    System.out.println("YTest::y");
  }
}
