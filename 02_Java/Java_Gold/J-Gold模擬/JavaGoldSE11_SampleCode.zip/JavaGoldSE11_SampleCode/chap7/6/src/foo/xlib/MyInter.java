package xlib;
public interface MyInter {
  String sayHello();
}