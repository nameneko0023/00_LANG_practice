package xlib;

public class XTest implements MyInter{ 
  @Override
  public String sayHello(){
    return "Hello";
  }
}
