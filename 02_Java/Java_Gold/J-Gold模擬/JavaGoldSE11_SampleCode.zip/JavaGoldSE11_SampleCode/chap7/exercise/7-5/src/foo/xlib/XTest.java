package xlib;

public class XTest {  
  public static void x() {
    System.out.println("XTest::x"); 
  }
}
