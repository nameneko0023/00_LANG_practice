package app;
import xlib.XTest;
public class Main {  
  public static void main(String[] args) {
    System.out.println("Module System!"); 
    XTest.x();
  }
}
