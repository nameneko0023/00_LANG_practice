package dd.ee; 
import aa.bb.Play;

public class Main {  
  public static void main(String[] args) {
    Play.x();
  }
}
