package aa.bb; 

public class Play {  
  public static void x() {
    System.out.println("Play::x"); 
  }
}
