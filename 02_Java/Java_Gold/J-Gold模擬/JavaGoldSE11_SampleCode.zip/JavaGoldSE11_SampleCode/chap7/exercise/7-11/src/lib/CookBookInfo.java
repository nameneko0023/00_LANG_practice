package com.seshop.impl;
import com.seshop.BookInfo;

public class CookBookInfo implements BookInfo{ 
  @Override
  public String sayTitle(){
    return "CookBookInfo";
  }
}
