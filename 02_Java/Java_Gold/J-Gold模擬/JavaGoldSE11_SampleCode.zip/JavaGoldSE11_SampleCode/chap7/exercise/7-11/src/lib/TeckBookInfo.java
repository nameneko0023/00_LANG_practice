package com.seshop.impl;
import com.seshop.BookInfo;

public class TeckBookInfo implements BookInfo{ 
  @Override
  public String sayTitle(){
    return "TeckBookInfo";
  }
}
