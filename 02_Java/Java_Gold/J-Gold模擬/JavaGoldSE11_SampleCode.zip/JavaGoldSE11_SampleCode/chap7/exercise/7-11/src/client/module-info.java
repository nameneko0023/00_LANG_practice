
module client { 
  requires lib;
  uses com.seshop.BookInfo;
} 
