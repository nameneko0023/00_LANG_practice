package com.seshop;
public interface BookInfo {
  String sayTitle();
}