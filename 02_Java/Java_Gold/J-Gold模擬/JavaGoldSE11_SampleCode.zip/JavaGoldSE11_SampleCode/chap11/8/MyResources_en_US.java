import java.util.ListResourceBundle;

public class MyResources_en_US extends ListResourceBundle {
  protected Object[][] getContents() {
    Object[][] contents = {{"data",   "MyResources_en_US.class"}};
    return contents;
  }
}