import java.util.ListResourceBundle;

public class MyResources_en extends ListResourceBundle {
  protected Object[][] getContents() {
    Object[][] contents = {{"data",   "MyResources_en.class"}};
    return contents;
  }
}