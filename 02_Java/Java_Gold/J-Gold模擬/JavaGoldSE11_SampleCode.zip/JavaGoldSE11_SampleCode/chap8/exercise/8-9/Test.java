import java.util.concurrent.Callable;
public class Test {
  public static void main(String[] args) {
    //Callable o = () -> { System.out.println("wo"); return 10; };
    //Callable o = (int c) -> c++;
    //Callable o = () -> "hello" + "bye";
    //Callable o = () -> { return 10 };
    //Callable o = () -> 5;
    //Callable o = () -> { boolean b = true; };
    //Callable o = a -> { return "java"; };
  }
}
